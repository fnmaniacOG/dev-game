import { useState, useEffect } from "react";
import { ConnectionProvider, WalletProvider, useWallet } from "@solana/wallet-adapter-react";
import { WalletModalProvider, WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { PhantomWalletAdapter, SolflareWalletAdapter } from "@solana/wallet-adapter-wallets";
import { clusterApiUrl } from "@solana/web3.js";

import ExplorePanel   from "./components/ExplorePanel";
import PlayPanel      from "./components/PlayPanel";
import TournamentPanel from "./components/TournamentPanel";
import LaunchPanel    from "./components/LaunchPanel";
import PortfolioPanel from "./components/PortfolioPanel";
import DeployWizard   from "./components/DeployWizard";
import "./styles/globals.css";

// ─── Design tokens ────────────────────────────────────────────────────────────
// All components reference these CSS variables — change here to retheme globally

const CSS_VARS = `
  :root {
    --orange:       #E8621A;
    --orange-light: #FFF0E8;
    --orange-dark:  #B84A0E;
    --teal:         #0FA9A0;
    --teal-light:   #E6F7F6;
    --teal-dark:    #0A756F;
    --amber:        #D4860A;
    --amber-light:  #FEF3E0;
    --amber-dark:   #9A5F06;
    --red:          #D93B3B;
    --red-light:    #FDE8E8;
    --green:        #2EA043;
    --green-light:  #E6F4EA;

    --background:   #FAFAF8;
    --surface:      #F2F1EE;
    --surface-2:    #E8E6E1;
    --border:       #D8D5CE;
    --text:         #1A1816;
    --muted:        #7A756C;

    --font-sans:    'DM Sans', 'Helvetica Neue', sans-serif;
    --font-mono:    'DM Mono', 'Fira Code', monospace;

    --radius:       12px;
    --radius-sm:    8px;
    --radius-lg:    16px;
    --shadow:       0 1px 3px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.05);
    --shadow-lg:    0 4px 16px rgba(0,0,0,0.12), 0 12px 40px rgba(0,0,0,0.08);
  }

  @media (prefers-color-scheme: dark) {
    :root {
      --background:   #141210;
      --surface:      #1E1C19;
      --surface-2:    #2A2722;
      --border:       #363230;
      --text:         #F0EDE8;
      --muted:        #8A867E;
      --orange-light: #2A1A0E;
      --teal-light:   #0A1F1E;
      --amber-light:  #1F1404;
      --red-light:    #1F0808;
      --green-light:  #081408;
    }
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: var(--font-sans);
    background: var(--background);
    color: var(--text);
    -webkit-font-smoothing: antialiased;
    min-height: 100vh;
  }

  button { font-family: var(--font-sans); cursor: pointer; }
  input, select, textarea { font-family: var(--font-sans); }

  /* Wallet adapter overrides */
  .wallet-adapter-button {
    font-family: var(--font-sans) !important;
    background: var(--orange) !important;
    border-radius: var(--radius-sm) !important;
    height: 36px !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    padding: 0 14px !important;
  }
  .wallet-adapter-button:hover { background: var(--orange-dark) !important; }
  .wallet-adapter-modal-wrapper { font-family: var(--font-sans) !important; }
`;

// ─── Tab config ───────────────────────────────────────────────────────────────

type Tab = "explore" | "play" | "tournaments" | "launch" | "portfolio";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "explore",     label: "explore",     icon: "🗺" },
  { id: "play",        label: "play",        icon: "🎮" },
  { id: "tournaments", label: "prizes",      icon: "🏆" },
  { id: "launch",      label: "launch",      icon: "🚀" },
  { id: "portfolio",   label: "portfolio",   icon: "💼" },
];

// ─── Header ───────────────────────────────────────────────────────────────────

function Header({ tab, setTab }: { tab: Tab; setTab: (t: Tab) => void }) {
  const { publicKey } = useWallet();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <header style={{
      position: "sticky", top: 0, zIndex: 100,
      background: scrolled ? "rgba(250,250,248,0.92)" : "var(--background)",
      backdropFilter: scrolled ? "blur(12px)" : "none",
      borderBottom: `0.5px solid ${scrolled ? "var(--border)" : "transparent"}`,
      transition: "all 0.2s ease",
    }}>
      <div style={{
        maxWidth: 960, margin: "0 auto",
        padding: "0 16px",
        height: 56,
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        {/* Logo */}
        <div
          onClick={() => setTab("explore")}
          style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", userSelect: "none" }}
        >
          <div style={{
            width: 28, height: 28,
            background: "linear-gradient(135deg, var(--orange) 0%, var(--amber) 100%)",
            borderRadius: 7,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14,
          }}>🎮</div>
          <span style={{ fontSize: 16, fontWeight: 600, letterSpacing: "-0.3px" }}>
            dev<span style={{ color: "var(--orange)" }}>game</span>
          </span>
        </div>

        {/* Desktop nav */}
        <nav style={{ display: "flex", gap: 2 }} className="desktop-nav">
          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                padding: "6px 12px",
                borderRadius: 8,
                border: "none",
                background: tab === t.id ? "var(--orange-light)" : "transparent",
                color: tab === t.id ? "var(--orange)" : "var(--muted)",
                fontSize: 13,
                fontWeight: tab === t.id ? 500 : 400,
                transition: "all 0.15s",
              }}
            >
              {t.label}
            </button>
          ))}
        </nav>

        {/* Wallet */}
        <WalletMultiButton />
      </div>

      {/* Mobile nav */}
      <div style={{
        display: "flex",
        borderTop: "0.5px solid var(--border)",
        overflowX: "auto",
      }} className="mobile-nav">
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            style={{
              flex: 1, minWidth: 64,
              padding: "8px 4px",
              border: "none",
              background: tab === t.id ? "var(--orange-light)" : "transparent",
              color: tab === t.id ? "var(--orange)" : "var(--muted)",
              fontSize: 10,
              fontWeight: tab === t.id ? 600 : 400,
              display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
              transition: "all 0.15s",
            }}
          >
            <span style={{ fontSize: 16 }}>{t.icon}</span>
            {t.label}
          </button>
        ))}
      </div>
    </header>
  );
}

// ─── Main content ─────────────────────────────────────────────────────────────

function AppContent() {
  const [tab, setTab] = useState<Tab>("explore");
  const [launchMode, setLaunchMode] = useState(false);

  return (
    <div style={{ minHeight: "100vh" }}>
      <Header tab={tab} setTab={setTab} />

      <main style={{ maxWidth: 960, margin: "0 auto", padding: "24px 16px 80px" }}>
        {tab === "explore"     && <ExplorePanel onLaunch={() => { setTab("launch"); setLaunchMode(true); }} />}
        {tab === "play"        && <PlayPanel />}
        {tab === "tournaments" && <TournamentPanel />}
        {tab === "launch"      && <LaunchPanel />}
        {tab === "portfolio"   && <PortfolioPanel />}
      </main>
    </div>
  );
}

// ─── Root with providers ──────────────────────────────────────────────────────

const wallets = [new PhantomWalletAdapter(), new SolflareWalletAdapter()];
const endpoint = clusterApiUrl("devnet");

export default function App() {
  return (
    <>
      <style>{CSS_VARS}</style>
      <style>{`
        @media (min-width: 640px) {
          .desktop-nav { display: flex !important; }
          .mobile-nav  { display: none !important; }
        }
        @media (max-width: 639px) {
          .desktop-nav { display: none !important; }
          .mobile-nav  { display: flex !important; }
        }
      `}</style>
      <ConnectionProvider endpoint={endpoint}>
        <WalletProvider wallets={wallets} autoConnect>
          <WalletModalProvider>
            <AppContent />
          </WalletModalProvider>
        </WalletProvider>
      </ConnectionProvider>
    </>
  );
}
