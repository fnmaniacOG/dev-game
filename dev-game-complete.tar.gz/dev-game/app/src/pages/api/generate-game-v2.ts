import type { NextApiRequest, NextApiResponse } from "next";

// ─── Types ────────────────────────────────────────────────────────────────────

interface RaidTarget {
  name:        string;
  emoji:       string;
  region:      string;
  difficulty:  number;
  baseReward:  number;
  winOdds:     number;
  lore:        string;
  historicalFact: string;
}

interface QuizQuestion {
  question:     string;
  options:      string[];
  correct:      number;
  explanation:  string;
  difficulty:   "easy" | "medium" | "hard";
  reward:       number;
}

interface NFTRarityTier {
  name:         string;
  pct:          number;
  winBonus:     number;
  rewardMult:   number;
  stakingMult:  number;
  description:  string;
}

interface TokenomicsAllocation {
  playerRewards: number;
  liquidity:     number;
  dev:           number;
  treasury:      number;
  airdrop:       number;
}

export interface GeneratedGame {
  name:          string;
  description:   string;
  tokenSymbol:   string;
  tagline:       string;
  gameType:      number;
  isEducational: boolean;
  color:         string;
  emoji:         string;

  tokenomics: {
    totalSupply:   number;
    allocation:    TokenomicsAllocation;
    lockDays:      number;
    houseEdgeBps:  number;
    skillRewardBps: number;
    tournamentPoolBps: number;
    evAnalysis:    string;
    reasoning:     string;
  };

  nftTiers: NFTRarityTier[];

  // For RPG/raid games
  raidTargets?: RaidTarget[];

  // For quiz games
  questions?: QuizQuestion[];

  // For strategy games
  territories?: { name: string; resource: string; yield: number }[];

  artDirection: string;
  loreBackground: string;
  targetAudience: string;
}

// ─── Handler ──────────────────────────────────────────────────────────────────

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<GeneratedGame | { error: string }>,
) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { description, gameType, isEducational } = req.body as {
    description:   string;
    gameType:      string;
    isEducational: boolean;
  };

  if (!description || description.trim().length < 5) {
    return res.status(400).json({ error: "Please provide a game description" });
  }

  try {
    const prompt = buildPrompt(description, gameType, isEducational);

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key":    process.env.ANTHROPIC_API_KEY!,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model:      "claude-sonnet-4-20250514",
        max_tokens: 4096,
        system: `You are a blockchain game designer for Dev Game — a Solana game launchpad. 
You MUST respond with ONLY a valid JSON object matching the GeneratedGame schema. 
No preamble, no markdown, no backticks. Pure JSON only.
All tokenomics must sum to exactly 10000 basis points.
EV+ games must have skillRewardBps + tournamentPoolBps >= 8000.
houseEdgeBps must be <= 2000.`,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await response.json();
    const raw  = data.content?.[0]?.text ?? "";

    // Strip any accidental markdown fences
    const clean = raw.replace(/```json|```/g, "").trim();

    const generated: GeneratedGame = JSON.parse(clean);

    // Validate and auto-correct allocation sum
    const alloc = generated.tokenomics.allocation;
    const sum   = alloc.playerRewards + alloc.liquidity + alloc.dev + alloc.treasury + alloc.airdrop;
    if (sum !== 10_000) {
      // Auto-correct: adjust playerRewards
      generated.tokenomics.allocation.playerRewards += (10_000 - sum);
    }

    // Enforce EV+ hard constraints
    if (generated.gameType !== 2) { // not ponzi
      if (generated.tokenomics.skillRewardBps + generated.tokenomics.tournamentPoolBps < 8_000) {
        generated.tokenomics.skillRewardBps   = 6_000;
        generated.tokenomics.tournamentPoolBps = 2_000;
      }
    }
    if (generated.tokenomics.houseEdgeBps > 2_000) {
      generated.tokenomics.houseEdgeBps = 1_500;
    }

    return res.status(200).json(generated);

  } catch (err) {
    console.error("Game generation error:", err);
    return res.status(500).json({ error: "Failed to generate game. Please try again." });
  }
}

// ─── Prompt builder ───────────────────────────────────────────────────────────

function buildPrompt(description: string, gameType: string, isEducational: boolean): string {
  const typeGuide: Record<string, string> = {
    rpg:      "RPG/raid game with raid targets, enemies, and skill-based combat. gameType=0.",
    strategy: "Territory control strategy game with resource types and territories. gameType=3.",
    quiz:     "Educational quiz game with a question bank. gameType=4. isEducational=true.",
    ponzi:    "TRANSPARENT ponzi game — mandatory EV- but fully disclosed odds. gameType=2. houseEdgeBps up to 2000.",
    minigame: "Fast-paced mini game (flip, predict, race). gameType=1.",
  };

  const tokenomicsGuide: Record<string, string> = {
    rpg:      "playerRewards:4000, liquidity:2000, dev:1500, treasury:1500, airdrop:1000. skillRewardBps:6000, tournamentPoolBps:2000.",
    strategy: "playerRewards:4500, liquidity:2000, dev:1000, treasury:2000, airdrop:500. skillRewardBps:5500, tournamentPoolBps:2500.",
    quiz:     "playerRewards:6000, liquidity:2000, dev:1000, treasury:500, airdrop:500. skillRewardBps:7000, tournamentPoolBps:1000.",
    ponzi:    "playerRewards:3000, liquidity:3000, dev:2000, treasury:1500, airdrop:500. skillRewardBps:0, tournamentPoolBps:0. houseEdgeBps:1500.",
    minigame: "playerRewards:5500, liquidity:2500, dev:1000, treasury:500, airdrop:500. skillRewardBps:5000, tournamentPoolBps:3000.",
  };

  const typeInfo = typeGuide[gameType] ?? typeGuide.rpg;
  const allocInfo = tokenomicsGuide[gameType] ?? tokenomicsGuide.rpg;

  return `Generate a complete blockchain game for Dev Game (Solana launchpad) based on this description:

"${description}"

Game type: ${typeInfo}
Educational: ${isEducational}
Suggested tokenomics: ${allocInfo}

Return a JSON object with this exact structure:
{
  "name": "string (catchy 1-3 word name)",
  "description": "string (2-3 sentence description)",
  "tokenSymbol": "string (3-5 char ticker, e.g. $RAID)",
  "tagline": "string (one punchy line)",
  "gameType": number,
  "isEducational": boolean,
  "color": "string (hex color matching theme)",
  "emoji": "string (one emoji representing the game)",
  "tokenomics": {
    "totalSupply": number (100000000 to 1000000000),
    "allocation": {
      "playerRewards": number,
      "liquidity": number,
      "dev": number,
      "treasury": number,
      "airdrop": number
    },
    "lockDays": number (180-730),
    "houseEdgeBps": number (max 2000),
    "skillRewardBps": number,
    "tournamentPoolBps": number,
    "evAnalysis": "string (1-2 sentences on player EV)",
    "reasoning": "string (why these tokenomics fit this game type)"
  },
  "nftTiers": [
    {
      "name": "string", "pct": number, "winBonus": number,
      "rewardMult": number, "stakingMult": number, "description": "string"
    }
  ],
  ${gameType === "quiz" ? `"questions": [
    {
      "question": "string", "options": ["a","b","c","d"], "correct": number (0-3),
      "explanation": "string", "difficulty": "easy|medium|hard", "reward": number
    }
  ] (at least 10 questions),` : ""}
  ${gameType === "rpg" ? `"raidTargets": [
    {
      "name": "string", "emoji": "string", "region": "string",
      "difficulty": number (1-5), "baseReward": number,
      "winOdds": number (0.20-0.65), "lore": "string", "historicalFact": "string"
    }
  ] (5 targets, escalating difficulty),` : ""}
  ${gameType === "strategy" ? `"territories": [
    { "name": "string", "resource": "gold|iron|wood|magic|food", "yield": number }
  ] (25 territories for a 5x5 map),` : ""}
  "artDirection": "string (visual style, color palette, aesthetic)",
  "loreBackground": "string (2-3 sentence world/setting description)",
  "targetAudience": "string (who this game is for)"
}

Be creative and specific. The game theme should strongly match the description.
All allocations MUST sum to exactly 10000.
Return ONLY the JSON object, nothing else.`;
}
