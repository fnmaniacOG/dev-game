use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, Token, TokenAccount, MintTo, Transfer};

declare_id!("GovTok1111111111111111111111111111111111111");

// ─────────────────────────────────────────────────────────────────────────────
//  game.tok · Governance Program
//
//  $GTOK is the protocol governance token.
//  Distributed to top players across all games (airdrop),
//  plus early creators and protocol contributors.
//
//  Governance controls:
//  - Protocol fee rate (currently 2%)
//  - Max house edge cap (currently 20%)
//  - Liquidity matching cap (currently 5 SOL)
//  - Treasury spending proposals
//  - New game type approvals
//  - Upgrading protocol programs (via upgrade proposal)
//
//  Voting: 1 $GTOK = 1 vote. Quorum = 5% of circulating supply.
//  Pass threshold = 60% of votes cast. Timelock = 48h before execution.
// ─────────────────────────────────────────────────────────────────────────────

pub const QUORUM_BPS:          u64 = 500;    // 5% of supply
pub const PASS_THRESHOLD_BPS:  u64 = 6_000;  // 60% of votes
pub const VOTING_PERIOD_SECS:  i64 = 259_200; // 3 days
pub const TIMELOCK_SECS:       i64 = 172_800; // 48h
pub const MAX_DESCRIPTION_LEN: usize = 512;
pub const TOTAL_SUPPLY:        u64  = 100_000_000_000_000; // 100M with 6 decimals

/// Distribution:
/// 40% → players (earned via gameplay, tournaments, staking over 4 years)
/// 20% → creators  (earned as games gain traction)
/// 15% → team       (4-year vest, 1-year cliff)
/// 15% → treasury   (DAO controlled)
/// 10% → early airdrop (top 10K players at launch)

#[program]
pub mod governance {
    use super::*;

    /// Initialize the governance system. Called once at protocol launch.
    pub fn initialize(ctx: Context<Initialize>, params: InitParams) -> Result<()> {
        let gov = &mut ctx.accounts.governance_state;
        gov.authority          = ctx.accounts.authority.key();
        gov.gtok_mint          = ctx.accounts.gtok_mint.key();
        gov.treasury           = ctx.accounts.treasury.key();
        gov.protocol_fee_bps   = params.initial_fee_bps;
        gov.max_house_edge_bps = params.initial_max_house_edge;
        gov.match_cap_lamports = params.initial_match_cap;
        gov.proposal_count     = 0;
        gov.total_supply       = TOTAL_SUPPLY;
        gov.circulating        = 0;
        gov.bump               = *ctx.bumps.get("governance_state").unwrap();

        // Mint full supply to the governance state PDA
        // Distribution handled by separate claim/vest instructions
        let seeds: &[&[&[u8]]] = &[&[b"governance", &[gov.bump]]];
        let cpi_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            MintTo {
                mint:      ctx.accounts.gtok_mint.to_account_info(),
                to:        ctx.accounts.supply_vault.to_account_info(),
                authority: ctx.accounts.governance_state.to_account_info(),
            },
            seeds,
        );
        token::mint_to(cpi_ctx, TOTAL_SUPPLY)?;

        emit!(GovernanceInitialized {
            gtok_mint:    ctx.accounts.gtok_mint.key(),
            total_supply: TOTAL_SUPPLY,
        });
        Ok(())
    }

    /// Claim player airdrop. Verified against a merkle root of eligible wallets.
    pub fn claim_player_airdrop(
        ctx: Context<ClaimPlayerAirdrop>,
        merkle_proof: Vec<[u8; 32]>,
        amount: u64,
    ) -> Result<()> {
        let airdrop = &mut ctx.accounts.airdrop_claim;

        require!(!airdrop.claimed, GovError::AlreadyClaimed);
        require!(amount > 0,        GovError::ZeroAmount);

        // Verify merkle proof
        let leaf = anchor_lang::solana_program::keccak::hashv(&[
            ctx.accounts.claimant.key().as_ref(),
            &amount.to_le_bytes(),
        ]).0;

        let root = ctx.accounts.governance_state.airdrop_merkle_root;
        require!(
            verify_merkle_proof(leaf, &merkle_proof, root),
            GovError::InvalidMerkleProof
        );

        airdrop.claimed     = true;
        airdrop.claimant    = ctx.accounts.claimant.key();
        airdrop.amount      = amount;
        airdrop.claimed_at  = Clock::get()?.unix_timestamp;
        airdrop.bump        = *ctx.bumps.get("airdrop_claim").unwrap();

        let gov = &mut ctx.accounts.governance_state;
        gov.circulating += amount;

        // Transfer from supply vault to claimant
        let bump = gov.bump;
        let seeds: &[&[&[u8]]] = &[&[b"governance", &[bump]]];
        let cpi_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from:      ctx.accounts.supply_vault.to_account_info(),
                to:        ctx.accounts.claimant_ata.to_account_info(),
                authority: ctx.accounts.governance_state.to_account_info(),
            },
            seeds,
        );
        token::transfer(cpi_ctx, amount)?;

        emit!(AirdropClaimed {
            claimant: ctx.accounts.claimant.key(),
            amount,
        });
        Ok(())
    }

    /// Create a governance proposal.
    pub fn create_proposal(
        ctx: Context<CreateProposal>,
        params: ProposalParams,
    ) -> Result<()> {
        require!(params.description.len() <= MAX_DESCRIPTION_LEN, GovError::DescriptionTooLong);

        // Proposer must hold minimum $GTOK to create proposals
        let min_to_propose = ctx.accounts.governance_state.total_supply / 1000; // 0.1%
        require!(
            ctx.accounts.proposer_ata.amount >= min_to_propose,
            GovError::InsufficientTokens
        );

        let gov   = &mut ctx.accounts.governance_state;
        let prop  = &mut ctx.accounts.proposal;
        let now   = Clock::get()?.unix_timestamp;

        prop.id            = gov.proposal_count;
        prop.proposer      = ctx.accounts.proposer.key();
        prop.description   = params.description;
        prop.action        = params.action;
        prop.status        = ProposalStatus::Active as u8;
        prop.votes_for     = 0;
        prop.votes_against = 0;
        prop.created_at    = now;
        prop.voting_ends   = now + VOTING_PERIOD_SECS;
        prop.executed_at   = 0;
        prop.bump          = *ctx.bumps.get("proposal").unwrap();

        gov.proposal_count += 1;

        emit!(ProposalCreated {
            id:          prop.id,
            proposer:    ctx.accounts.proposer.key(),
            action:      params.action,
            voting_ends: prop.voting_ends,
        });
        Ok(())
    }

    /// Cast a vote on a proposal. Voting power = $GTOK balance at vote time.
    pub fn cast_vote(ctx: Context<CastVote>, support: bool) -> Result<()> {
        let prop    = &mut ctx.accounts.proposal;
        let receipt = &mut ctx.accounts.vote_receipt;
        let now     = Clock::get()?.unix_timestamp;

        require!(prop.status == ProposalStatus::Active as u8, GovError::ProposalNotActive);
        require!(now < prop.voting_ends,                       GovError::VotingEnded);

        let voting_power = ctx.accounts.voter_ata.amount;
        require!(voting_power > 0, GovError::NoVotingPower);

        receipt.voter        = ctx.accounts.voter.key();
        receipt.proposal_id  = prop.id;
        receipt.support      = support;
        receipt.power        = voting_power;
        receipt.voted_at     = now;
        receipt.bump         = *ctx.bumps.get("vote_receipt").unwrap();

        if support {
            prop.votes_for     += voting_power;
        } else {
            prop.votes_against += voting_power;
        }

        emit!(VoteCast {
            proposal_id: prop.id,
            voter:       ctx.accounts.voter.key(),
            support,
            power:       voting_power,
        });
        Ok(())
    }

    /// Finalize a proposal after voting period ends.
    pub fn finalize_proposal(ctx: Context<FinalizeProposal>) -> Result<()> {
        let gov  = &ctx.accounts.governance_state;
        let prop = &mut ctx.accounts.proposal;
        let now  = Clock::get()?.unix_timestamp;

        require!(
            prop.status == ProposalStatus::Active as u8,
            GovError::ProposalNotActive
        );
        require!(now >= prop.voting_ends, GovError::VotingNotEnded);

        let total_votes  = prop.votes_for + prop.votes_against;
        let quorum_votes = gov.circulating * QUORUM_BPS / 10_000;
        let passed = total_votes >= quorum_votes
            && prop.votes_for * 10_000 / total_votes.max(1) >= PASS_THRESHOLD_BPS;

        prop.status = if passed {
            ProposalStatus::Queued as u8  // queued for execution after timelock
        } else {
            ProposalStatus::Defeated as u8
        };

        emit!(ProposalFinalized {
            id:          prop.id,
            passed,
            votes_for:   prop.votes_for,
            votes_against: prop.votes_against,
        });
        Ok(())
    }

    /// Execute a passed proposal after the timelock.
    pub fn execute_proposal(ctx: Context<ExecuteProposal>) -> Result<()> {
        let gov  = &mut ctx.accounts.governance_state;
        let prop = &mut ctx.accounts.proposal;
        let now  = Clock::get()?.unix_timestamp;

        require!(
            prop.status == ProposalStatus::Queued as u8,
            GovError::NotQueued
        );
        require!(
            now >= prop.voting_ends + TIMELOCK_SECS,
            GovError::TimelockNotExpired
        );

        // Execute the governance action
        match prop.action {
            GovernanceAction::SetProtocolFeeBps(bps) => {
                require!(bps <= 500, GovError::InvalidParameter); // max 5%
                gov.protocol_fee_bps = bps;
            }
            GovernanceAction::SetMaxHouseEdgeBps(bps) => {
                require!(bps <= 3000, GovError::InvalidParameter); // max 30%
                gov.max_house_edge_bps = bps;
            }
            GovernanceAction::SetMatchCap(lamports) => {
                require!(lamports <= 50_000_000_000, GovError::InvalidParameter); // max 50 SOL
                gov.match_cap_lamports = lamports;
            }
            GovernanceAction::TreasuryTransfer { amount, recipient: _ } => {
                require!(amount <= 1_000_000_000_000, GovError::InvalidParameter); // 1M token max
            }
        }

        prop.status      = ProposalStatus::Executed as u8;
        prop.executed_at = now;

        emit!(ProposalExecuted {
            id:     prop.id,
            action: prop.action,
        });
        Ok(())
    }

    /// Set the merkle root for the player airdrop (called by team pre-launch).
    pub fn set_airdrop_merkle_root(
        ctx: Context<SetMerkleRoot>,
        root: [u8; 32],
    ) -> Result<()> {
        require!(
            ctx.accounts.authority.key() == ctx.accounts.governance_state.authority,
            GovError::Unauthorized
        );
        ctx.accounts.governance_state.airdrop_merkle_root = root;
        Ok(())
    }
}

// ─── Merkle proof verification ────────────────────────────────────────────────

fn verify_merkle_proof(leaf: [u8; 32], proof: &[[u8; 32]], root: [u8; 32]) -> bool {
    let mut current = leaf;
    for sibling in proof {
        current = if current <= *sibling {
            anchor_lang::solana_program::keccak::hashv(&[&current, sibling]).0
        } else {
            anchor_lang::solana_program::keccak::hashv(&[sibling, &current]).0
        };
    }
    current == root
}

// ─── Account Contexts ────────────────────────────────────────────────────────

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,

    #[account(
        init, payer = authority,
        mint::decimals  = 6,
        mint::authority = governance_state,
    )]
    pub gtok_mint: Account<'info, Mint>,

    #[account(
        init, payer = authority,
        seeds = [b"governance"], bump,
        space = GovernanceState::LEN,
    )]
    pub governance_state: Account<'info, GovernanceState>,

    #[account(
        init, payer = authority,
        token::mint      = gtok_mint,
        token::authority = governance_state,
        seeds = [b"supply_vault"], bump,
    )]
    pub supply_vault: Account<'info, TokenAccount>,

    /// CHECK: treasury multisig
    pub treasury: AccountInfo<'info>,

    pub token_program:  Program<'info, Token>,
    pub system_program: Program<'info, System>,
    pub rent:           Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct ClaimPlayerAirdrop<'info> {
    #[account(mut)]
    pub claimant: Signer<'info>,

    #[account(mut)]
    pub governance_state: Account<'info, GovernanceState>,

    #[account(
        init, payer = claimant,
        seeds = [b"airdrop_claim", claimant.key().as_ref()],
        bump, space = AirdropClaim::LEN,
    )]
    pub airdrop_claim: Account<'info, AirdropClaim>,

    #[account(mut, seeds = [b"supply_vault"], bump)]
    pub supply_vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub claimant_ata: Account<'info, TokenAccount>,

    pub token_program:  Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(params: ProposalParams)]
pub struct CreateProposal<'info> {
    #[account(mut)]
    pub proposer: Signer<'info>,

    #[account(mut)]
    pub governance_state: Account<'info, GovernanceState>,

    #[account(
        init, payer = proposer,
        seeds = [b"proposal", governance_state.proposal_count.to_le_bytes().as_ref()],
        bump, space = Proposal::LEN,
    )]
    pub proposal: Account<'info, Proposal>,

    pub proposer_ata:   Account<'info, TokenAccount>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CastVote<'info> {
    #[account(mut)]
    pub voter: Signer<'info>,

    #[account(mut)]
    pub proposal: Account<'info, Proposal>,

    #[account(
        init, payer = voter,
        seeds = [b"vote_receipt", proposal.key().as_ref(), voter.key().as_ref()],
        bump, space = VoteReceipt::LEN,
    )]
    pub vote_receipt: Account<'info, VoteReceipt>,

    pub voter_ata:      Account<'info, TokenAccount>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct FinalizeProposal<'info> {
    pub governance_state: Account<'info, GovernanceState>,
    #[account(mut)]
    pub proposal: Account<'info, Proposal>,
}

#[derive(Accounts)]
pub struct ExecuteProposal<'info> {
    #[account(mut)]
    pub governance_state: Account<'info, GovernanceState>,
    #[account(mut)]
    pub proposal: Account<'info, Proposal>,
}

#[derive(Accounts)]
pub struct SetMerkleRoot<'info> {
    pub authority: Signer<'info>,
    #[account(mut, seeds = [b"governance"], bump = governance_state.bump)]
    pub governance_state: Account<'info, GovernanceState>,
}

// ─── State ────────────────────────────────────────────────────────────────────

#[account]
pub struct GovernanceState {
    pub authority:           Pubkey,    // 32
    pub gtok_mint:           Pubkey,    // 32
    pub treasury:            Pubkey,    // 32
    pub protocol_fee_bps:    u16,       // 2
    pub max_house_edge_bps:  u16,       // 2
    pub match_cap_lamports:  u64,       // 8
    pub proposal_count:      u64,       // 8
    pub total_supply:        u64,       // 8
    pub circulating:         u64,       // 8
    pub airdrop_merkle_root: [u8; 32],  // 32
    pub bump:                u8,        // 1
}
impl GovernanceState {
    pub const LEN: usize = 8 + 32 + 32 + 32 + 2 + 2 + 8 + 8 + 8 + 8 + 32 + 1 + 64;
}

#[account]
pub struct Proposal {
    pub id:            u64,               // 8
    pub proposer:      Pubkey,            // 32
    pub description:   String,            // 4 + 512
    pub action:        GovernanceAction,  // variable (~50)
    pub status:        u8,                // 1
    pub votes_for:     u64,               // 8
    pub votes_against: u64,               // 8
    pub created_at:    i64,               // 8
    pub voting_ends:   i64,               // 8
    pub executed_at:   i64,               // 8
    pub bump:          u8,                // 1
}
impl Proposal {
    pub const LEN: usize = 8 + 8 + 32 + 516 + 64 + 1 + 8 + 8 + 8 + 8 + 8 + 1 + 32;
}

#[account]
pub struct VoteReceipt {
    pub voter:       Pubkey, // 32
    pub proposal_id: u64,    // 8
    pub support:     bool,   // 1
    pub power:       u64,    // 8
    pub voted_at:    i64,    // 8
    pub bump:        u8,     // 1
}
impl VoteReceipt {
    pub const LEN: usize = 8 + 32 + 8 + 1 + 8 + 8 + 1 + 32;
}

#[account]
pub struct AirdropClaim {
    pub claimant:   Pubkey, // 32
    pub amount:     u64,    // 8
    pub claimed:    bool,   // 1
    pub claimed_at: i64,    // 8
    pub bump:       u8,     // 1
}
impl AirdropClaim {
    pub const LEN: usize = 8 + 32 + 8 + 1 + 8 + 1 + 32;
}

// ─── Types ────────────────────────────────────────────────────────────────────

#[repr(u8)]
pub enum ProposalStatus { Active = 0, Queued = 1, Executed = 2, Defeated = 3, Cancelled = 4 }

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq)]
pub enum GovernanceAction {
    SetProtocolFeeBps(u16),
    SetMaxHouseEdgeBps(u16),
    SetMatchCap(u64),
    TreasuryTransfer { amount: u64, recipient: Pubkey },
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct InitParams {
    pub initial_fee_bps:       u16,
    pub initial_max_house_edge: u16,
    pub initial_match_cap:     u64,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct ProposalParams {
    pub description: String,
    pub action:      GovernanceAction,
}

// ─── Events ───────────────────────────────────────────────────────────────────

#[event] pub struct GovernanceInitialized { pub gtok_mint: Pubkey, pub total_supply: u64 }
#[event] pub struct AirdropClaimed        { pub claimant: Pubkey, pub amount: u64 }
#[event] pub struct ProposalCreated       { pub id: u64, pub proposer: Pubkey, pub action: GovernanceAction, pub voting_ends: i64 }
#[event] pub struct VoteCast              { pub proposal_id: u64, pub voter: Pubkey, pub support: bool, pub power: u64 }
#[event] pub struct ProposalFinalized     { pub id: u64, pub passed: bool, pub votes_for: u64, pub votes_against: u64 }
#[event] pub struct ProposalExecuted      { pub id: u64, pub action: GovernanceAction }

// ─── Errors ───────────────────────────────────────────────────────────────────

#[error_code]
pub enum GovError {
    #[msg("Airdrop already claimed")]             AlreadyClaimed,
    #[msg("Invalid merkle proof")]                InvalidMerkleProof,
    #[msg("Zero amount")]                         ZeroAmount,
    #[msg("Proposal is not active")]              ProposalNotActive,
    #[msg("Voting period has ended")]             VotingEnded,
    #[msg("Voting period has not ended yet")]     VotingNotEnded,
    #[msg("No voting power (zero $GTOK balance)")] NoVotingPower,
    #[msg("Proposal is not queued for execution")] NotQueued,
    #[msg("Timelock has not expired")]            TimelockNotExpired,
    #[msg("Description too long")]                DescriptionTooLong,
    #[msg("Insufficient $GTOK to create proposal")] InsufficientTokens,
    #[msg("Parameter out of allowed range")]      InvalidParameter,
    #[msg("Unauthorized")]                        Unauthorized,
}
