use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};

declare_id!("Referral111111111111111111111111111111111111");

pub const REFEREE_BONUS_BPS: u64    = 1_000;  // 10% bonus on first 10 raids
pub const REFERRER_REWARD_BPS: u64  = 500;    // 5% of referee's rewards for 30 days
pub const CREATOR_REFERRAL_BPS: u64 = 100;    // 1% of referred game's protocol fees for 12 months
pub const REFEREE_RAID_CAP: u32     = 10;     // first 10 raids get the bonus
pub const REFERRAL_WINDOW_DAYS: i64 = 30;
pub const CREATOR_WINDOW_DAYS: i64  = 365;

#[error_code]
pub enum ReferralError {
    #[msg("Referral code already used")]
    AlreadyReferred,
    #[msg("Cannot refer yourself")]
    SelfReferral,
    #[msg("Referral window has expired")]
    WindowExpired,
    #[msg("Bonus already used up")]
    BonusExhausted,
    #[msg("Arithmetic overflow")]
    Overflow,
}

#[account]
pub struct ReferralLink {
    pub referrer:       Pubkey,
    pub referee:        Pubkey,
    pub game:           Pubkey,
    pub created_at:     i64,
    pub expires_at:     i64,        // referrer_reward_bps active until here
    pub referee_raids:  u32,        // tracks first-N-raids bonus
    pub total_earned:   u64,        // total referrer has earned from this link
    pub bump:           u8,
}

impl ReferralLink {
    pub const LEN: usize = 8 + 32 * 3 + 8 * 3 + 4 + 8 + 1;
}

#[account]
pub struct CreatorReferral {
    pub referrer:       Pubkey,     // existing creator who referred a new creator
    pub new_creator:    Pubkey,     // new creator who launched a game
    pub game_mint:      Pubkey,     // the launched game's mint
    pub created_at:     i64,
    pub expires_at:     i64,
    pub total_earned:   u64,
    pub bump:           u8,
}

impl CreatorReferral {
    pub const LEN: usize = 8 + 32 * 3 + 8 * 3 + 8 + 1;
}

#[program]
pub mod referral {
    use super::*;

    /// Register a player referral. Referee gets bonus on first 10 raids.
    pub fn register_player_referral(
        ctx: Context<RegisterPlayerReferral>,
    ) -> Result<()> {
        require!(
            ctx.accounts.referrer.key() != ctx.accounts.referee.key(),
            ReferralError::SelfReferral
        );

        let now = Clock::get()?.unix_timestamp;

        let link = &mut ctx.accounts.referral_link;
        link.referrer      = ctx.accounts.referrer.key();
        link.referee       = ctx.accounts.referee.key();
        link.game          = ctx.accounts.game.key();
        link.created_at    = now;
        link.expires_at    = now
            .checked_add(REFERRAL_WINDOW_DAYS * 24 * 60 * 60)
            .ok_or(ReferralError::Overflow)?;
        link.referee_raids = 0;
        link.total_earned  = 0;
        link.bump          = ctx.bumps.referral_link;

        emit!(PlayerReferred {
            referrer: ctx.accounts.referrer.key(),
            referee:  ctx.accounts.referee.key(),
            game:     ctx.accounts.game.key(),
        });

        Ok(())
    }

    /// Distribute referral bonus after a raid reward is calculated.
    /// Called by the game client immediately after raid settlement.
    pub fn distribute_referral_bonus(
        ctx: Context<DistributeBonus>,
        base_reward: u64,
    ) -> Result<()> {
        let link = &ctx.accounts.referral_link;
        let now  = Clock::get()?.unix_timestamp;

        // Referee bonus: 10% on first 10 raids
        let referee_gets_bonus = link.referee_raids < REFEREE_RAID_CAP as u32;
        let referee_bonus = if referee_gets_bonus {
            base_reward
                .checked_mul(REFEREE_BONUS_BPS)
                .and_then(|v| v.checked_div(10_000))
                .ok_or(ReferralError::Overflow)?
        } else {
            0
        };

        // Referrer reward: 5% of rewards, for 30 days
        let referrer_in_window = now < link.expires_at;
        let referrer_reward = if referrer_in_window {
            base_reward
                .checked_mul(REFERRER_REWARD_BPS)
                .and_then(|v| v.checked_div(10_000))
                .ok_or(ReferralError::Overflow)?
        } else {
            0
        };

        // Transfer referee bonus from referral vault → referee
        if referee_bonus > 0 {
            let game_key = ctx.accounts.game.key();
            let seeds: &[&[&[u8]]] = &[&[
                b"referral_vault",
                game_key.as_ref(),
                &[ctx.accounts.referral_vault_bump.load()? as u8],
            ]];
            token::transfer(
                CpiContext::new_with_signer(
                    ctx.accounts.token_program.to_account_info(),
                    Transfer {
                        from:      ctx.accounts.referral_vault.to_account_info(),
                        to:        ctx.accounts.referee_token_account.to_account_info(),
                        authority: ctx.accounts.referral_vault.to_account_info(),
                    },
                    seeds,
                ),
                referee_bonus,
            )?;
        }

        // Transfer referrer reward from referral vault → referrer
        if referrer_reward > 0 {
            let game_key = ctx.accounts.game.key();
            let seeds: &[&[&[u8]]] = &[&[
                b"referral_vault",
                game_key.as_ref(),
                &[ctx.accounts.referral_vault_bump.load()? as u8],
            ]];
            token::transfer(
                CpiContext::new_with_signer(
                    ctx.accounts.token_program.to_account_info(),
                    Transfer {
                        from:      ctx.accounts.referral_vault.to_account_info(),
                        to:        ctx.accounts.referrer_token_account.to_account_info(),
                        authority: ctx.accounts.referral_vault.to_account_info(),
                    },
                    seeds,
                ),
                referrer_reward,
            )?;
        }

        let link = &mut ctx.accounts.referral_link;
        link.referee_raids = link.referee_raids.saturating_add(1);
        link.total_earned  = link
            .total_earned
            .checked_add(referrer_reward)
            .ok_or(ReferralError::Overflow)?;

        Ok(())
    }

    /// Register a creator referral (creator refers another creator who launches a game).
    pub fn register_creator_referral(
        ctx: Context<RegisterCreatorReferral>,
        game_mint: Pubkey,
    ) -> Result<()> {
        let now = Clock::get()?.unix_timestamp;

        let cr = &mut ctx.accounts.creator_referral;
        cr.referrer    = ctx.accounts.referrer.key();
        cr.new_creator = ctx.accounts.new_creator.key();
        cr.game_mint   = game_mint;
        cr.created_at  = now;
        cr.expires_at  = now
            .checked_add(CREATOR_WINDOW_DAYS * 24 * 60 * 60)
            .ok_or(ReferralError::Overflow)?;
        cr.total_earned = 0;
        cr.bump         = ctx.bumps.creator_referral;

        emit!(CreatorReferred {
            referrer:    ctx.accounts.referrer.key(),
            new_creator: ctx.accounts.new_creator.key(),
            game_mint,
        });

        Ok(())
    }
}

// ─── Account contexts ─────────────────────────────────────────────────────────

#[derive(Accounts)]
pub struct RegisterPlayerReferral<'info> {
    #[account(mut)]
    pub referee: Signer<'info>,

    /// CHECK: referrer wallet
    pub referrer: UncheckedAccount<'info>,

    /// CHECK: game account
    pub game: UncheckedAccount<'info>,

    #[account(
        init,
        payer = referee,
        space = ReferralLink::LEN,
        seeds = [b"referral", referrer.key().as_ref(), referee.key().as_ref(), game.key().as_ref()],
        bump,
    )]
    pub referral_link: Account<'info, ReferralLink>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct DistributeBonus<'info> {
    /// CHECK: game authority
    pub authority: Signer<'info>,

    /// CHECK: game account
    pub game: UncheckedAccount<'info>,

    #[account(
        mut,
        seeds = [b"referral", referral_link.referrer.as_ref(), referral_link.referee.as_ref(), game.key().as_ref()],
        bump  = referral_link.bump,
    )]
    pub referral_link: Account<'info, ReferralLink>,

    #[account(mut)]
    pub referral_vault: Account<'info, TokenAccount>,

    /// CHECK: vault bump stored separately
    pub referral_vault_bump: AccountLoader<'info, VaultBump>,

    #[account(mut)]
    pub referee_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub referrer_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
}

#[account(zero_copy)]
pub struct VaultBump {
    pub bump: u64,
}

#[derive(Accounts)]
pub struct RegisterCreatorReferral<'info> {
    #[account(mut)]
    pub new_creator: Signer<'info>,

    /// CHECK: existing creator who made the referral
    pub referrer: UncheckedAccount<'info>,

    #[account(
        init,
        payer = new_creator,
        space = CreatorReferral::LEN,
        seeds = [b"creator_referral", referrer.key().as_ref(), new_creator.key().as_ref()],
        bump,
    )]
    pub creator_referral: Account<'info, CreatorReferral>,

    pub system_program: Program<'info, System>,
}

// ─── Events ───────────────────────────────────────────────────────────────────

#[event]
pub struct PlayerReferred {
    pub referrer: Pubkey,
    pub referee:  Pubkey,
    pub game:     Pubkey,
}

#[event]
pub struct CreatorReferred {
    pub referrer:    Pubkey,
    pub new_creator: Pubkey,
    pub game_mint:   Pubkey,
}
