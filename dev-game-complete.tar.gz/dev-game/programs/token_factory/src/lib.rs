use anchor_lang::prelude::*;
use anchor_spl::{
    associated_token::AssociatedToken,
    metadata::{
        create_metadata_accounts_v3, mpl_token_metadata::types::DataV2,
        CreateMetadataAccountsV3, Metadata,
    },
    token::{self, Mint, MintTo, SetAuthority, Token, TokenAccount},
};
use anchor_spl::token::spl_token::instruction::AuthorityType;

declare_id!("TokFact11111111111111111111111111111111111111");

// ─── Constants ────────────────────────────────────────────────────────────────

pub const TOTAL_BPS: u64 = 10_000;
pub const MAX_NAME_LEN: usize = 32;
pub const MAX_SYMBOL_LEN: usize = 10;
pub const MAX_URI_LEN: usize = 200;
pub const MIN_PLAYER_REWARD_BPS: u64 = 2_000; // 20% minimum to players
pub const MAX_DEV_BPS: u64 = 3_000;           // 30% max dev allocation

// ─── Error codes ──────────────────────────────────────────────────────────────

#[error_code]
pub enum TokenFactoryError {
    #[msg("Allocation basis points must sum to exactly 10,000")]
    AllocationMismatch,
    #[msg("Player reward allocation too low — minimum 20%")]
    PlayerRewardTooLow,
    #[msg("Dev allocation too high — maximum 30%")]
    DevAllocTooHigh,
    #[msg("Token supply must be between 1M and 10B")]
    InvalidSupply,
    #[msg("Name too long (max 32 chars)")]
    NameTooLong,
    #[msg("Symbol too long (max 10 chars)")]
    SymbolTooLong,
    #[msg("Mint authority already revoked")]
    MintAuthorityAlreadyRevoked,
    #[msg("Arithmetic overflow")]
    Overflow,
}

// ─── State ────────────────────────────────────────────────────────────────────

#[account]
pub struct GameToken {
    pub creator:           Pubkey,   // wallet that deployed
    pub mint:              Pubkey,   // SPL mint address
    pub game_state:        Pubkey,   // linked game_state account (set post-registration)
    pub total_supply:      u64,
    pub player_rewards:    u64,      // tokens allocated to player reward vault
    pub liquidity:         u64,      // tokens allocated to LP
    pub dev_allocation:    u64,      // tokens allocated to developer
    pub treasury:          u64,      // tokens allocated to treasury
    pub airdrop:           u64,      // tokens allocated to airdrop
    pub player_reward_bps: u16,
    pub liquidity_bps:     u16,
    pub dev_bps:           u16,
    pub treasury_bps:      u16,
    pub airdrop_bps:       u16,
    pub mint_revoked:      bool,
    pub created_at:        i64,
    pub bump:              u8,
}

impl GameToken {
    pub const LEN: usize = 8       // discriminator
        + 32 + 32 + 32             // creator, mint, game_state
        + 8 * 5                    // supply fields
        + 2 * 5                    // bps fields
        + 1                        // mint_revoked
        + 8                        // created_at
        + 1;                       // bump
}

// ─── Instructions ─────────────────────────────────────────────────────────────

#[program]
pub mod token_factory {
    use super::*;

    /// Create a fungible game token with fixed supply and on-chain allocation constraints.
    /// After minting, mint authority is immediately revoked — supply is permanently fixed.
    pub fn create_fungible_token(
        ctx: Context<CreateFungibleToken>,
        params: CreateTokenParams,
    ) -> Result<()> {
        // ── Validate params ──────────────────────────────────────────────────
        require!(
            params.name.len() <= MAX_NAME_LEN,
            TokenFactoryError::NameTooLong
        );
        require!(
            params.symbol.len() <= MAX_SYMBOL_LEN,
            TokenFactoryError::SymbolTooLong
        );
        require!(
            params.total_supply >= 1_000_000 && params.total_supply <= 10_000_000_000,
            TokenFactoryError::InvalidSupply
        );

        // ── Validate allocation sums to 10,000 bps ──────────────────────────
        let alloc_sum = (params.player_reward_bps as u64)
            .checked_add(params.liquidity_bps as u64)
            .and_then(|s| s.checked_add(params.dev_bps as u64))
            .and_then(|s| s.checked_add(params.treasury_bps as u64))
            .and_then(|s| s.checked_add(params.airdrop_bps as u64))
            .ok_or(TokenFactoryError::Overflow)?;

        require!(alloc_sum == TOTAL_BPS, TokenFactoryError::AllocationMismatch);
        require!(
            params.player_reward_bps as u64 >= MIN_PLAYER_REWARD_BPS,
            TokenFactoryError::PlayerRewardTooLow
        );
        require!(
            params.dev_bps as u64 <= MAX_DEV_BPS,
            TokenFactoryError::DevAllocTooHigh
        );

        let supply = params.total_supply;

        // ── Compute token amounts per allocation ─────────────────────────────
        let player_rewards = supply
            .checked_mul(params.player_reward_bps as u64)
            .and_then(|v| v.checked_div(TOTAL_BPS))
            .ok_or(TokenFactoryError::Overflow)?;
        let liquidity = supply
            .checked_mul(params.liquidity_bps as u64)
            .and_then(|v| v.checked_div(TOTAL_BPS))
            .ok_or(TokenFactoryError::Overflow)?;
        let dev_alloc = supply
            .checked_mul(params.dev_bps as u64)
            .and_then(|v| v.checked_div(TOTAL_BPS))
            .ok_or(TokenFactoryError::Overflow)?;
        let treasury = supply
            .checked_mul(params.treasury_bps as u64)
            .and_then(|v| v.checked_div(TOTAL_BPS))
            .ok_or(TokenFactoryError::Overflow)?;
        let airdrop = supply
            .checked_mul(params.airdrop_bps as u64)
            .and_then(|v| v.checked_div(TOTAL_BPS))
            .ok_or(TokenFactoryError::Overflow)?;

        // ── Create on-chain metadata via Metaplex ────────────────────────────
        let creator_key = ctx.accounts.creator.key();
        let signer_seeds: &[&[&[u8]]] = &[&[
            b"game_token",
            creator_key.as_ref(),
            ctx.accounts.mint.key().as_ref(),
            &[ctx.bumps.game_token],
        ]];

        create_metadata_accounts_v3(
            CpiContext::new_with_signer(
                ctx.accounts.token_metadata_program.to_account_info(),
                CreateMetadataAccountsV3 {
                    metadata:         ctx.accounts.metadata.to_account_info(),
                    mint:             ctx.accounts.mint.to_account_info(),
                    mint_authority:   ctx.accounts.creator.to_account_info(),
                    update_authority: ctx.accounts.creator.to_account_info(),
                    payer:            ctx.accounts.creator.to_account_info(),
                    system_program:   ctx.accounts.system_program.to_account_info(),
                    rent:             ctx.accounts.rent.to_account_info(),
                },
                signer_seeds,
            ),
            DataV2 {
                name:                 params.name.clone(),
                symbol:               params.symbol.clone(),
                uri:                  params.metadata_uri.clone(),
                seller_fee_basis_points: 0,
                creators:             None,
                collection:           None,
                uses:                 None,
            },
            true,  // is_mutable (can update metadata URI; supply is fixed by revoking mint auth)
            true,  // update_authority_is_signer
            None,
        )?;

        // ── Mint full supply to creator vault ────────────────────────────────
        token::mint_to(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                MintTo {
                    mint:      ctx.accounts.mint.to_account_info(),
                    to:        ctx.accounts.creator_vault.to_account_info(),
                    authority: ctx.accounts.creator.to_account_info(),
                },
            ),
            supply,
        )?;

        // ── Revoke mint authority — supply is now PERMANENTLY FIXED ──────────
        token::set_authority(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                SetAuthority {
                    current_authority: ctx.accounts.creator.to_account_info(),
                    account_or_mint:   ctx.accounts.mint.to_account_info(),
                },
            ),
            AuthorityType::MintTokens,
            None, // None = revoke
        )?;

        // ── Persist state ────────────────────────────────────────────────────
        let game_token = &mut ctx.accounts.game_token;
        game_token.creator        = ctx.accounts.creator.key();
        game_token.mint           = ctx.accounts.mint.key();
        game_token.game_state     = Pubkey::default(); // set when game is registered
        game_token.total_supply   = supply;
        game_token.player_rewards = player_rewards;
        game_token.liquidity      = liquidity;
        game_token.dev_allocation = dev_alloc;
        game_token.treasury       = treasury;
        game_token.airdrop        = airdrop;
        game_token.player_reward_bps = params.player_reward_bps;
        game_token.liquidity_bps     = params.liquidity_bps;
        game_token.dev_bps           = params.dev_bps;
        game_token.treasury_bps      = params.treasury_bps;
        game_token.airdrop_bps       = params.airdrop_bps;
        game_token.mint_revoked   = true;
        game_token.created_at     = Clock::get()?.unix_timestamp;
        game_token.bump           = ctx.bumps.game_token;

        emit!(TokenCreated {
            creator:    ctx.accounts.creator.key(),
            mint:       ctx.accounts.mint.key(),
            supply,
            symbol:     params.symbol,
        });

        Ok(())
    }

    /// Link the game_state PDA to this token after game registration.
    pub fn link_game_state(
        ctx: Context<LinkGameState>,
        game_state_key: Pubkey,
    ) -> Result<()> {
        ctx.accounts.game_token.game_state = game_state_key;
        Ok(())
    }
}

// ─── Instruction params ───────────────────────────────────────────────────────

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct CreateTokenParams {
    pub name:              String,
    pub symbol:            String,
    pub metadata_uri:      String,
    pub total_supply:      u64,
    pub player_reward_bps: u16,
    pub liquidity_bps:     u16,
    pub dev_bps:           u16,
    pub treasury_bps:      u16,
    pub airdrop_bps:       u16,
}

// ─── Account contexts ─────────────────────────────────────────────────────────

#[derive(Accounts)]
#[instruction(params: CreateTokenParams)]
pub struct CreateFungibleToken<'info> {
    #[account(mut)]
    pub creator: Signer<'info>,

    #[account(
        init,
        payer  = creator,
        mint::decimals  = 6,
        mint::authority = creator,
    )]
    pub mint: Account<'info, Mint>,

    #[account(
        init,
        payer  = creator,
        space  = GameToken::LEN,
        seeds  = [b"game_token", creator.key().as_ref(), mint.key().as_ref()],
        bump,
    )]
    pub game_token: Account<'info, GameToken>,

    #[account(
        init_if_needed,
        payer             = creator,
        associated_token::mint      = mint,
        associated_token::authority = creator,
    )]
    pub creator_vault: Account<'info, TokenAccount>,

    /// CHECK: Metaplex validates this account
    #[account(mut)]
    pub metadata: UncheckedAccount<'info>,

    pub token_program:          Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub token_metadata_program: Program<'info, Metadata>,
    pub system_program:         Program<'info, System>,
    pub rent:                   Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct LinkGameState<'info> {
    pub creator: Signer<'info>,

    #[account(
        mut,
        seeds = [b"game_token", creator.key().as_ref(), game_token.mint.as_ref()],
        bump  = game_token.bump,
        constraint = game_token.creator == creator.key(),
    )]
    pub game_token: Account<'info, GameToken>,
}

// ─── Events ───────────────────────────────────────────────────────────────────

#[event]
pub struct TokenCreated {
    pub creator: Pubkey,
    pub mint:    Pubkey,
    pub supply:  u64,
    pub symbol:  String,
}
